package com.stackroute.keepnote.model;

import java.util.Date;

public class Category {

	/*
	 * This class should have five fields
	 * (categoryId,categoryName,categoryDescription,
	 * categoryCreatedBy,categoryCreationDate). This class should also contain the
	 * getters and setters for the fields along with the toString method. The value
	 * of categoryCreationDate should not be accepted from the user but should be
	 * always initialized with the system date.
	 */

    public String getCategoryId() {
        return null;
    }

    public void setCategoryId(String categoryId) {
       
    }

    public String getCategoryName() {
        return null;
    }

    public void setCategoryName(String categoryName) {
        
    }

    public String getCategoryDescription() {
        return null;
    }

    public void setCategoryDescription(String categoryDescription) {
      
    }

    public String getCategoryCreatedBy() {
        return null;
    }

    public void setCategoryCreatedBy(String categoryCreatedBy) {
       
    }

    public Date getCategoryCreationDate() {
        return null;
    }

    public void setCategoryCreationDate(Date categoryCreationDate) {
      
    }

}
