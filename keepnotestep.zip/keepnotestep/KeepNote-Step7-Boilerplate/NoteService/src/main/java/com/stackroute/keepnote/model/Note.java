package com.stackroute.keepnote.model;

import java.util.Date;
import java.util.List;

public class Note {
	
	/*
	 * This class should have eight fields
	 * (noteId,noteTitle,noteContent,noteStatus,createdAt,
	 * category,reminder,createdBy). This class should also contain the
	 * getters and setters for the fields along with the no-arg , parameterized
	 * constructor and toString method. The value of createdAt should not be
	 * accepted from the user but should be always initialized with the system date.
	 * 
	 */


	    // getters & setters

	    public int getNoteId() {
	        return 0;
	    }

	    public void setNoteId(int noteId) {
	     
	    }

	    public String getNoteTitle() {
	        return null;
	    }

	    public void setNoteTitle(String noteTitle) {
	       
	    }

	    public String getNoteContent() {
	        return null;
	    }

	    public void setNoteContent(String noteContent) {
	       
	    }

	    public String getNoteStatus() {
	        return null;
	    }

	    public void setNoteStatus(String noteStatus) {
	       
	    }

	    public Date getNoteCreationDate() {
	        return null;
	    }

	    public void setNoteCreationDate(Date noteCreationDate) {
	        
	    }

	    public String getNoteCreatedBy() {
	        return null;
	    }

	    public void setNoteCreatedBy(String noteCreatedBy) {
	        
	    }

	    public Category getCategory() {
	        return null;
	    }

	    public void setCategory(Category category) {
	       
	    }

	    public List<Reminder> getReminders() {
	        return null;
	    }

	    public void setReminders(List<Reminder> reminders) {
	    
	    }
	
}
