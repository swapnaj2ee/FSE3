//User table fields: user_id, user_name, user_added_date, user_password, user_mobile

create table User(

user_id varchar(20) primary key,
user_name varchar(30) not null, 
user_added_date date , 
user_password varchar(20) not null, 
user_mobile varchar(15)

)


//Note table fields: note_id, note_title, note_content, note_status, note_creation_date

create table Note(
note_id int auto_increment primary key, 
note_title varchar(30) not null, 
note_content varchar(2000), 
note_status varchar(20), 
note_creation_date timestamp 
)

//Category table fields : category_id, category_name, category_descr, category_creation_date, category_creator

create table Category (
category_id int auto_increment primary key, 
category_name varchar(30) not null, 
category_descr varchar(200), 
category_creation_date timestamp, 
category_creator varchar(30)
)

//Reminder table fields : reminder_id, reminder_name, reminder_descr, reminder_type, reminder_creation_date, reminder_creator

create table Reminder (
reminder_id int primary key, 
reminder_name varchar(30) not null, 
reminder_descr varchar(300), 
reminder_type varchar(20), 
reminder_creation_date timestamp, 
reminder_creator varchar(30)
)

//NoteCategory table fields : notecategory_id, note_id, category_id

create table NoteCategory(
notecategory_id int primary key, 
note_id int not null, 
category_id int not null,
foreign key(note_id) references Note(note_id),
foreign key(category_id) references Category(category_id)
)

//Notereminder table fields : notereminder_id, note_id, reminder_id

create table Notereminder (
notereminder_id int primary key, 
note_id int not null, 
reminder_id int not null,
foreign key(note_id) references Note(note_id),
foreign key(reminder_id) references Reminder(reminder_id)
)

//usernote table fields : usernote_id, user_id, note_id

create table usernote(
usernote_id int primary key, 
user_id varchar(30) not null, 
note_id int not null,
foreign key(user_id) references User(user_id),
foreign key(note_id) references Note(note_id)
)

//Insert the rows into the created tables (Note, Category, Reminder, User, UserNote, NoteReminder and NoteCategory).

insert into User values(1,'shiva',current_date(),'shiva@123',9000138907);

insert into User values(2,'sai',current_date(),'sai@123',9573577143);

select * from User;


insert into Note(note_title, note_content, note_status) values('note1','content1','status1');

update Note set note_creation_date=current_date() where note_id=1;

insert into Note(note_title, note_content, note_status,note_creation_date) values('note2','content2','status2',current_date());

delete from Note where note_id=2;

select * from Note;


insert into Category(category_name, category_descr, category_creation_date, category_creator) values('Category1','description1',current_date(),'creator1');

insert into Category(category_name, category_descr, category_creation_date, category_creator) values('Category2','description2',current_date(),'creator2');

select * from Category;



insert into Reminder values(1,'reminder1','rdesc1','rtype1',current_date(),'rcreator1');

insert into Reminder values(2,'reminder2','rdesc2','rtype2',current_date(),'rcreator2');


select * from Reminder;



insert into NoteCategory values(1,1,1);

insert into NoteCategory values(2,3,2);


select * from NoteCategory;



insert into Notereminder values(1,1,1);

insert into Notereminder values(2,3,2);

select * from Notereminder;



insert into usernote values(1,1,1);

insert into usernote values(2,2,3);


select * from usernote;


//Fetch the row from User table based on Id and Password.

select * from User where user_id=1 and user_password='shiva@123';

//Fetch all the rows from Note table based on the field note_creation_date.

select * from Note where note_creation_date=current_date();

//Fetch all the Categories created after the particular Date.

select * from Category where category_creation_date >='2019-01-01';

//Fetch all the Note ID from UserNote table for a given User.

select note_id from usernote where user_id=1;

//Write Update query to modify particular Note for the given note Id.

update Note set note_title='title2' where note_id=2;

//Fetch all the Notes from the Note table by a particular User.

select * from Note where note_id in(select note_id from usernote where user_id=1);

//Fetch all the Notes from the Note table for a particular Category.

select * from Note where note_id in(select note_id from NoteCategory where category_id=1);

//Fetch all the reminder details for a given note id.

select * from Reminder where reminder_id in(select reminder_id from Notereminder where note_id=1);

//Fetch the reminder details for a given reminder id.

select * from Reminder where reminder_id=1;

//Write a query to create a new Note from particular User (Use Note and UserNote tables - insert statement).

insert into Note select * from Note n join usernote u on n.note_id=u.note_id;

//Write a query to create a new Note from particular User to particular Category(Use Note and NoteCategory tables - insert statement)

insert into Note select * from Note n join NoteCategory c on n.note_id=c.note_id;

//Write a query to set a reminder for a particular note (Use Reminder and NoteReminder tables - insert statement)

insert into Reminder select * from Reminder r join Notereminder b on r.reminder_id=b.reminder_id;

//Write a query to delete particular Note added by a User(Note and UserNote tables - delete statement)

delete from Note where note_id in(select note_id from usernote where user_id=1);

//Write a query to delete particular Note from particular Category(Note and NoteCategory tables - delete statement)

delete from Note where note_id in(select note_id from NoteCategory where category_id=1);

Create a trigger to delete all matching records from UserNote, NoteReminder and NoteCategory table when :
1. A particular note is deleted from Note table (all the matching records from UserNote, NoteReminder and NoteCategory should be removed automatically) 

Create trigger Note_delete_cascade 

before delete 
on Note 

for each row

delete from UserNote, NoteCategory, NoteReminder using UserNote inner join NoteCategory inner join NoteReminder on UserNote.note_id = NoteCategory.note_id and UserNote.note_id = NoteReminder.note_id where UserNote.note_id not in(select note_id from Note);

2. A particular user is deleted from User table (all the matching notes should be removed automatically)

Create trigger Note_delete_cascade 

before delete 
on User 

for each row

delete from UserNote, NoteCategory, NoteReminder using UserNote inner join NoteCategory inner join NoteReminder on UserNote.note_id = NoteCategory.note_id and UserNote.note_id = NoteReminder.note_id where UserNote.note_id not in(select note_id from Note);

