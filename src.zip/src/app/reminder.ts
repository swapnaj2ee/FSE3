export class Reminder{
	reminderName:string;
	id:string;
	reminderDescription:string;
	reminderType:string
}