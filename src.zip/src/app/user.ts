export class  User{
    userid:string;
    userpassword:string;
    firstname:string;
    lastname:string;
    role:string;
}