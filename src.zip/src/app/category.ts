export class Category{
   id:string;
    categoryName:string;
    categoryDescription:string;
    categoryCreatedBy:string;
    categoryCreationDate:Date;
}