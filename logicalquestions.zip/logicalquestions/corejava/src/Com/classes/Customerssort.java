package Com.classes;

import java.util.ArrayList;import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Customerssort {
	
	public static void main(String[] args) {
		
	
	List<Customers> customerlist=new ArrayList<Customers>();
	
	Customers c1=new Customers("swapna",28,"female");
	Customers c2=new Customers("nayana",26,"female");
	Customers c3=new Customers("jai",30,"male");
	Customers c4=new Customers("chinnu",26,"male");
	Customers c5=new Customers("mary",28,"female");
	Customers c6=new Customers("mary",28,"female");
	Customers c7=new Customers("jai",28,"male");
	
	customerlist.add(c1);
	customerlist.add(c2);
	customerlist.add(c3);
	customerlist.add(c4);
	customerlist.add(c5);
	customerlist.add(c6);
	customerlist.add(c7);
	Set<Customers> setcustomers=new HashSet<Customers>(customerlist);
	
	System.out.println("display the customer list"+"@@@@@@@@@@@@@@"+setcustomers);
	
	
List outputlist=	customerlist.stream().filter(Customers->Customers.getGender().equals("male")&& Customers.getAge()>25)
	.collect(Collectors.toList());
System.out.println("list of customers"+"..........."+outputlist);

 customerlist.stream().map(Customers->Customers.getName())
 .forEach(System.out::println);
 
 customerlist.sort(Comparator.comparing(Customers->Customers.getName()));
 
 System.out.println("sorting customerlist"+"&&&&&&&&&&&&&&&&"+customerlist);
 
 Double avg=customerlist.stream().collect(Collectors.averagingInt(cust->cust.getAge()));
 
 
 System.out.println("customer avarage age is"+"************"+avg);
 

	
}
}
