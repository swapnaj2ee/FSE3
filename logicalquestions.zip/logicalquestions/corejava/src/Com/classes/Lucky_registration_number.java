package Com.classes;

import java.util.regex.Pattern;

public class Lucky_registration_number {
	
	String renum="";
	int flag=0;
	
	
	public static  int checkregistrationnum(String renum) {
	if(renum==null) {
		System.out.println("NUMBER IS EMPTY");
		
	}
		
		Pattern.compile("(KA|DL)/d{2}[A-Z]{1,2}[1-9]/d{3}");
		System.out.println("swapna");
		int n=substring("DL12101410");
		if(n==6) {
			System.out.println("LUCKY REGISTRATION NUMBER");
			
		}
		
		
		return 1;
	}
	

	public static void main(String[] args) {
		
		
	int flag=	checkregistrationnum("DLXX101410");
	System.out.println(flag);
	
	}
	public static int substring(String renum) {
		int sum=0;
		
	String n= renum.substring(5, 9);
	
int num=Integer.parseInt(n);
//System.out.println(num);
	while(num!=0) {
	sum=sum + num%10;
	num=num /10;
	}
	
	//System.out.println(sum);
		return sum;
	}

}