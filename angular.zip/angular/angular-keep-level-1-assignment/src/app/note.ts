export class Note {
}
