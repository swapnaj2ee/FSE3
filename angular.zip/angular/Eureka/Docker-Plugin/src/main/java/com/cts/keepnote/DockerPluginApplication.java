package com.cts.keepnote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerPluginApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerPluginApplication.class, args);
	}

}
